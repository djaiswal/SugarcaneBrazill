#' This function gets one strip from simulation results which contain multiple year of simulation in a single grid
#' 
#' @param CombinedRow is a single row of output containing simulation results for multple year for a single grid
#' @param OutputColunID is the fixed ID such as soillat/soillon
#' @param OutputColumnVarName is the name of predicted variables such as year,stem,leaf etc.
#' @return a data frame that containing only fixed ID, variable names. Numbe of row are dependent on how many years are in a single input row
#' @export

StripOneRow <- function(CombinedRow,OutputColumnID,OutputColumnVarName){
  NumberofColumns <- length(OutputColumnID) + length(OutputColumnVarName)
  TotalColumns <- dim(CombinedRow)[2]
  IDcolumns <- length(OutputColumnID)
  RemainingColumns <-  TotalColumns - IDcolumns
  NumberofRows <- RemainingColumns/length(OutputColumnVarName)
  output <- data.frame(matrix(NA,nrow=NumberofRows,ncol=NumberofColumns))
  for (i in 1:NumberofRows){
    firstindex <- IDcolumns + (i-1)*length(OutputColumnVarName) +1 
    lastindex <-  firstindex + length(OutputColumnVarName)-1
    index <- c(c(1:length(OutputColumnID)),c(firstindex:lastindex))
    output[i,] <- CombinedRow[,index]
  }
  return(output)
}
