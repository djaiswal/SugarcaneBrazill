Get_Day1_DayN <- function(wetdata,thresholdtemp){
  wetdata$rownumber <- row(wetdata)[,1]
  N <- dim(wetdata)[1]
  size <- N/2
  firsthalf <- wetdata[1:size,]
  secondhalf <- wetdata[(size+1):N,]
  firsthalf <- firsthalf[firsthalf$Temp <=thresholdtemp,]
  secondhalf <- secondhalf[secondhalf$Temp <= thresholdtemp,]
  if(dim(firsthalf)[1]==0){
    day1 <- 1
  } else{
    day1 <- max(firsthalf$rownumber)/24 +1
  }
  
  if(dim(secondhalf)[1]==0){
    dayn <- N/24
  } else {
    dayn <- min(secondhalf$rownumber)/24 -1
  }
  if(dayn <= day1){
    error ("No valid day 1 nd dayn based on threshold value")
  }
  day1 <- round(day1,0)
  dayn <- round(dayn,0)
  output <- list(day1=day1, dayn=dayn)
  return(output)
}
  