#' This function Combines all the output spreaded over multiple files after regional simulations on BioCluster into one single dataframe
#' 
#' @param  ResultDirectory is directory containing multiple .RData file of outputs after all regional simulations are completed
#' @param OutputColumnID is a list of strings identifying Identity of Output such as soillat soillon etc
#' @param OutputColumnVarName is a list of variables being saved in output RData
#' @param firstyear is firstyear of simulations
#' @param lastyear is last year of simulations
#' @return a dataframe combining all the reesults spreaded in multiple files due to parallelization
#' @export


CombineAllOutputs <- function(ResultDirectory,OutputColumnID,OutputColumnVarName,firstyear,lastyear){
  filenames <- Sys.glob(paste(ResultDirectory,"/*.RData",sep=""))
  NumberofColumn <- length(OutputColumnID) + length(OutputColumnVarName)*(lastyear-firstyear+1)
  output <- data.frame(matrix(NA,nrow=1,ncol=NumberofColumn))
  output <- output[-1,,drop = FALSE]
  colnames(output) <- c(OutputColumnID,rep(OutputColumnVarName,(lastyear-firstyear+1)))
  for (file in filenames){
    finaloutput <- NULL
    load(file)
    flag <- CheckOutPutDimensions(dim(finaloutput)[2],length(OutputColumnID),length(OutputColumnVarName),firstyear,lastyear)
        if(flag == TRUE){
                      output <- rbind(output,finaloutput)
        }else {
          stop (paste("Dimension do not match for the following file:",file,sep=""))
        }
  }
  colnames(output) <- c(OutputColumnID,rep(OutputColumnVarName,(lastyear-firstyear+1)))
  return(output)
}  



  

