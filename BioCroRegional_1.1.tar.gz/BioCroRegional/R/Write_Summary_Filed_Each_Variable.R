#' Purpose of this function is to use alltogetherresult data frame and write individual files for each variable that will be processes using shapefile and other GIS packages for each variable individually
#' @param alltogetherdataframe is a data frame containing LAT, LON and variables such as stem, leaf etc
#' @param directoryname is where we want to store individual files
#' @param fileextension is representing scenario- as all the scenario files are saved in a single folder

Write_Summary_Filed_Each_Variable <- function(alltogetherdataframe,directoryname,filenameextension){
  stem <- data.frame(lon=alltogetherdataframe$LON,lat=alltogetherdataframe$LAT,Yield = alltogetherdataframe[[3]])
  outputfile <- paste(directoryname,"/stem_",filenameextension,sep="")
  write.csv(stem, outputfile, row.names=FALSE)
  
  GreenLeaf <- data.frame(lon=alltogetherdataframe$LON,lat=alltogetherdataframe$LAT,Yield = alltogetherdataframe[[5]])
  outputfile <- paste(directoryname,"/GreenLeaf_",filenameextension,sep="")
  write.csv(GreenLeaf, outputfile, row.names=FALSE)
  
  
  LeafLitter <- data.frame(lon=alltogetherdataframe$LON,lat=alltogetherdataframe$LAT,Yield = alltogetherdataframe[[9]]) 
  outputfile <- paste(directoryname,"/LeafLitter_",filenameextension,sep="")
  write.csv(LeafLitter, outputfile, row.names=FALSE)
  
  
  Root <- data.frame(lon=alltogetherdataframe$LON,lat=alltogetherdataframe$LAT,Yield = alltogetherdataframe[[7]])
  outputfile <- paste(directoryname,"/Root_",filenameextension,sep="")
  write.csv(Root, outputfile, row.names=FALSE)
  return(0)
}
