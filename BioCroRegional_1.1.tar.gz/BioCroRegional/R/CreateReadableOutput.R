#' This function returns a dataframe with location ID and predicted yield variables for multuple years of simulations from first to last
#' 
#' @param CombinedOutput is dataframe that is output from regional simulations on Biocluster
#' @param OoutputColumnID such as soil lat, soillon
#' @param OutputColumnVarName, such as year, stem, leaf
#' @param firstyear first year of simulation
#' @param lastyear last year of simulations
#' @return a dataframe with location ID and predicted yield variables for multiple years (from first to last year)
#' @export


CreateReadableOutput <- function(CombinedOutput,OutputColumnID,OutputColumnVarName,firstyear,lastyear){
  NumberofColumn <- length(OutputColumnID) + length(OutputColumnVarName) + 1 # 1 is for uniquesoilID
  output <- data.frame(matrix(NA,nrow=1,ncol=NumberofColumn))
  output <- output[-1,,drop = FALSE]
  N <-dim(CombinedOutput)[1]
  for (i in 1:N){
    tmp <- StripOneRow(CombinedOutput[i,],OutputColumnID,OutputColumnVarName)
    tmp$uniquesoilID <- i
    output <- rbind(output,tmp)
  }
  colnames(output) <- c(OutputColumnID,OutputColumnVarName,"uniquesoilID")
  return(output)
}  
