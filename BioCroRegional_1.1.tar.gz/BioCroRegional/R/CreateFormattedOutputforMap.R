#' Purpose of this function is to use ReadableOutput from regional simulations (containing all the years) and create a summary of mean and standard deviation of all the variables
#' 
#' @param ReadableOutput is ReadableOutput, Output of CreateReadableOutput.R
#' @return Dataframe containing mean and sd of all the variables based on yearly values
#' @export

CreateFormattedOutputforMap <- function(ReadableOutput){
  tmp <- group_by(ReadableOutput,uniquesoilID)
  output <- summarise(tmp, count = n(), lat = mean(soillat),lon=mean(soillon),StemHarvested = mean(HarvestedStem),GreenLeaf = mean(leaf1),Root = mean(root1),LeafLitter = mean(leaflitter1),
                      StemSD = sd(HarvestedStem),GreenLeafSD = sd(leaf1),RootSD = sd(root1),LeafLitterSD = sd(leaflitter1))
  return(output)
}
