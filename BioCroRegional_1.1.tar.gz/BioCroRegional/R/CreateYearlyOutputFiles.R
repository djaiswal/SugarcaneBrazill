#' Purpose of this function is to take Output of Regional Simulations of Brazil and produce a multiple files according to year containing predicted yield at simulation points
#' 
#' @param ResultDirectory contains all the result in .RData format
#' @param OutputColumnID contains all the non-repeating output column ID in result dataframe such as soil lat, lon, ID
#' @param OutputColumnVarName contains all the variables (repeating over multueple years) in the result data frame, such as stem, leaf, deadleaf
#' @param firrstyear is first year of simulation
#' @param lastyear is lastyear of simulations
#' @param  LocationofYearlySummary where all the year file will be storied
#' @export

CreateYearlyOutputFiles <- function(ResultDirectory,OutputColumnID,OutputColumnVarName,firstyear,lastyear,LocationofYearlySummary){
  CombinedOutput <- CombineAllOutputs(ResultDirectory,OutputColumnID,OutputColumnVarName,firstyear,lastyear)
  ReadableOutput <- CreateReadableOutput(CombinedOutput,OutputColumnID,OutputColumnVarName,firstyear,lastyear)
  for (year in firstyear:lastyear){
    tmp <- ReadableOutput[ReadableOutput$currentyear==year,]
    write.csv(tmp,file=paste(LocationofYearlySummary,"/",year,".csv",sep=""), row.names=FALSE)
  }
  return()
}

