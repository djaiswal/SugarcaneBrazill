#' This function  is to check id dimension of Biocluster result .RData  in result folder and inputs such as column ID, variables, and first amnd last year are consistent or not
#' 
#' @param OutputCols are saved in result data frame
#' @param FixedID are fixed ID, non repeating column names such as soil lar, lon
#' @param Var is a list of variables which are saved and are being repeated in each row depending on number of years of simulations
#' @param firstyear first year of simulations
#' @param lastyear last year of simulation
#' @return integer 1 if consistency is satisfied and 0 if not
#' @export

CheckOutPutDimensions <- function(OutputCols,FixedID,Var,firstyear,lastyear){
  RequiredColumns <- FixedID + (lastyear-firstyear+1)*Var
  return(RequiredColumns == OutputCols)
}
