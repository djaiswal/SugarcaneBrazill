#' Purpose of this function is to take Output of Regional Simulations of Brazil and produce a simple fle containing mean and sd of output variables. 
#' 
#' @param ResultDirectory contains all the result in .RData format
#' @param OutputColumnID contains all the non-repeating output column ID in result dataframe such as soil lat, lon, ID
#' @param OutputColumnVarName contains all the variables (repeating over multueple years) in the result data frame, such as stem, leaf, deadleaf
#' @param firstyear is first year of simulation
#' @param lastyear is lastyear of simulations
#' @export

ProcessRegionalOutput <- function(ResultDirectory,OutputColumnID,OutputColumnVarName,firstyear,lastyear){
  CombinedOutput <- CombineAllOutputs(ResultDirectory,OutputColumnID,OutputColumnVarName,firstyear,lastyear)
  ReadableOutput <- CreateReadableOutput(CombinedOutput,OutputColumnID,OutputColumnVarName,firstyear,lastyear)
  result <- CreateFormattedOutputforMap(ReadableOutput)
  return(result)
}
